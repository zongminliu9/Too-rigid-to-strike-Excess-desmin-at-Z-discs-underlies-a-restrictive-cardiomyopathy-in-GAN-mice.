# Analysis map

| Article item | Script | Output directory |
|---|---|---|
| Figure 3; Z-disc and I-band geometry | `scripts/reproduce_figure3.py` | `outputs/figure3_geometry/` |
| Figure 5; packing and Linker-12 tiling | `scripts/reproduce_figure5_calculations.py` | `outputs/figure5_packing/` |
| Figure 5; structural input preparation and contact analysis | `scripts/prepare_af3_inputs.py`, `scripts/analyze_af3_outputs.py` | `data/structural_inputs/`, `outputs/structural_analysis/` |
| Figure 6; force and hydrogen-bond threshold | `scripts/reproduce_figure6_force.py` | `outputs/figure6_force/` |
| Figure 7; reduced dynamics | `scripts/reproduce_figure7.py` | `outputs/figure7_dynamics/` |
| Figure 7; sensitivity analysis | `scripts/reproduce_figure7_sensitivity.py` | `outputs/figure7_sensitivity/` |
| Figure 8; progression model | `scripts/reproduce_figure8.py` | `outputs/figure8_progression/` |
| Desmin-vimentin alignment | `scripts/sequence_alignment.py` | `outputs/sequence_alignment/` |
