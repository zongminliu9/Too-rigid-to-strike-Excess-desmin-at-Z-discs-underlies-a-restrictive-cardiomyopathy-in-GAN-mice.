# Desmin-GAN computational models

Python code accompanying the iScience article **“Too rigid to strike: Excess desmin at Z-discs underlies a restrictive cardiomyopathy in GAN mice.”**

The repository implements the geometric, packing, force-threshold, dynamical, sensitivity, progression, sequence-alignment, and structural analyses described in the article and its Supplementary Information.

## Installation

Using Conda:

```bash
conda env create -f environment.yml
conda activate desmin-gan-models
```

Using pip:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Run all analyses

```bash
python scripts/run_all.py
```

Generated tables, JSON summaries, and figures are written to `outputs/`.

Run the numerical regression tests with:

```bash
pytest -q
```

## Included analyses

- Z-disc and I-band geometric modeling
- Linker-12 contour-length and circumference-tiling calculations
- Desmin packing calculations
- Worm-like-chain force and hydrogen-bond threshold calculations
- Reduced I-band dynamical modeling and hysteresis analysis
- Latin-hypercube sensitivity analysis
- Desmin-crowding progression modeling
- Desmin-vimentin sequence alignment
- AlphaFold 3 input preparation and structural contact analysis

## Structural analysis

AlphaFold 3 input files are provided in `data/structural_inputs/`. Inter-chain contacts and predicted aligned error maps can be analyzed with:

```bash
python scripts/analyze_af3_outputs.py model_1.cif model_2.cif --pae model_1.json model_2.json
```

## Repository structure

- `config/parameters.yaml`: model parameters
- `data/reference_sequences/`: human desmin and vimentin sequences
- `data/structural_inputs/`: AlphaFold 3 input files and sequence fragments
- `src/desmin_models/`: reusable model functions
- `scripts/`: analysis entry points
- `tests/`: numerical regression tests
- `outputs/`: generated results

## Citation

Please cite the associated iScience article and the Zenodo software record.
