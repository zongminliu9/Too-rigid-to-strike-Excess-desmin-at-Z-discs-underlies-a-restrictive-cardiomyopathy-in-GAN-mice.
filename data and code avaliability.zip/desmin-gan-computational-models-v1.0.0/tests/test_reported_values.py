from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from desmin_models.geometry import linker_contour_length, per_layer_ring_model, full_circumference_tiling
from desmin_models.packing import packing_requirement
from desmin_models.force import wlc_force_pN, aggregated_ring_tension_nN, hbond_threshold
from desmin_models.progression import fit_growth_rate


def test_linker_contour():
    assert abs(linker_contour_length() - 5.76) < 1e-12


def test_per_layer_ring():
    result = per_layer_ring_model(100, 115, 48.6, 0.70, 5.76)
    assert result["N_rounded"] == 10
    assert abs(result["delta_linker_nm"] - 4.71238898) < 1e-5
    assert result["within_contour_limit"]


def test_full_tiling():
    result = full_circumference_tiling(660, 770, 48.6, 0.70, 66, 5.76)
    assert abs(result["delta_linker_nm"] - 5.236) < 0.01
    assert result["within_contour_limit"]


def test_packing_range():
    rows = [
        packing_requirement(100, 11, 3, 3, 3),
        packing_requirement(100, 11, 6, 3, 1),
    ]
    assert rows[0]["percent_increase"] == 100.0
    assert abs(rows[1]["percent_increase"] - 16.6666666667) < 1e-6


def test_force_order():
    force = wlc_force_pN(300, 700, 0.7, 4.1)
    assert 5.0 < force < 6.0
    ring = aggregated_ring_tension_nN(force, 40, 25, 30)
    assert 4.5 < ring < 5.0
    bonds = hbond_threshold(5, 660, 50, 7)
    assert 600 < bonds["total_bonds"] < 630


def test_growth_rate():
    rate = fit_growth_rate([6, 9, 12], [1.2, 1.5, 3.0])
    assert abs(rate - 0.0686837654) < 1e-10
