#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
import pandas as pd
import matplotlib.pyplot as plt
from desmin_models.io import load_parameters, ensure_output_dir
from desmin_models.structural import interchain_contacts, load_pae


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze AlphaFold 3 multimer outputs.")
    parser.add_argument("structures", nargs="+", help="PDB or mmCIF model files")
    parser.add_argument("--pae", nargs="*", default=[], help="PAE JSON files")
    args = parser.parse_args()

    p = load_parameters()
    out = ensure_output_dir("structural_analysis")
    all_rows = []
    for model_file in args.structures:
        rows = interchain_contacts(model_file, p["structural"]["contact_cutoff_A"])
        for row in rows:
            row["model_file"] = str(model_file)
        all_rows.extend(rows)
    pd.DataFrame(all_rows).to_csv(out / "interchain_contacts_under_3p5A.csv", index=False)

    for pae_path in args.pae:
        pae = load_pae(pae_path)
        fig, ax = plt.subplots(figsize=(5, 4.5))
        image = ax.imshow(pae, origin="lower", aspect="auto")
        fig.colorbar(image, ax=ax, label="PAE (A)")
        ax.set(xlabel="Residue", ylabel="Residue", title=Path(pae_path).stem)
        fig.tight_layout()
        fig.savefig(out / f"{Path(pae_path).stem}_PAE.png", dpi=300)
        plt.close(fig)

    print(json.dumps({
        "models": len(args.structures),
        "contacts": len(all_rows),
        "cutoff_A": p["structural"]["contact_cutoff_A"],
    }, indent=2))


if __name__ == "__main__":
    main()
