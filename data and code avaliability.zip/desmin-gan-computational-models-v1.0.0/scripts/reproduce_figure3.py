#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from desmin_models.io import load_parameters, ensure_output_dir
from desmin_models.geometry import (
    linker_contour_length, per_layer_ring_model, full_circumference_tiling,
    radius_from_iband, nebulin_angle_deg, sinusoid_between,
)


def main() -> None:
    p = load_parameters()
    g = p["geometry"]
    out = ensure_output_dir("figure3_geometry")
    linker_max = linker_contour_length(
        g["per_layer"]["linker12_residues"],
        g["per_layer"]["contour_per_residue_nm"],
    )
    per_layer = per_layer_ring_model(
        g["per_layer"]["D_min_nm"], g["per_layer"]["D_max_nm"],
        g["per_layer"]["rod_length_nm"], g["per_layer"]["rod_overlap_fraction"], linker_max,
    )
    full = full_circumference_tiling(
        g["full_circumference"]["D_min_nm"], g["full_circumference"]["D_max_nm"],
        g["per_layer"]["rod_length_nm"], g["per_layer"]["rod_overlap_fraction"],
        g["full_circumference"]["N"], linker_max,
    )
    I = np.linspace(g["sensitivity"]["I_min_um"], g["sensitivity"]["I_max_um"], 251)
    R = radius_from_iband(
        I, g["sensitivity"]["I_min_um"], g["sensitivity"]["I_max_um"],
        g["sensitivity"]["R_min_nm"], g["sensitivity"]["R_max_nm"],
    )
    phi = nebulin_angle_deg(I, R, g["sensitivity"]["titin_insertion_radius_nm"])
    pd.DataFrame({"I_band_um": I, "desmin_radius_nm": R, "nebulin_angle_deg": phi}).to_csv(
        out / "iband_radius_angle.csv", index=False
    )
    summary = {
        "per_layer_N10": per_layer,
        "full_circumference_N66": full,
        "sensitivity_endpoints": {
            "phi_at_Imax_deg": float(phi[-1]),
            "phi_at_Imin_deg": float(phi[0]),
            "delta_phi_deg": float(phi[0] - phi[-1]),
        },
    }
    (out / "geometry_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    f = g["figure3"]
    t = np.linspace(0, f["duration_s"], 1200)
    wt_d = sinusoid_between(t, f["WT_D_min_um"], f["WT_D_max_um"], f["frequency_hz"])
    gan_d = f["GAN_D_mean_um"] + f["GAN_D_amplitude_um"] * np.sin(
        2 * np.pi * f["frequency_hz"] * t - np.pi / 2
    )
    wt_i = sinusoid_between(t, f["WT_I_min_um"], f["WT_I_max_um"], f["frequency_hz"], 0.0)
    gan_i = sinusoid_between(t, f["GAN_I_min_um"], f["GAN_I_max_um"], f["frequency_hz"], 0.0)
    pd.DataFrame({
        "time_s": t,
        "WT_Z_disc_diameter_um": wt_d,
        "GAN_Z_disc_diameter_um": gan_d,
        "WT_I_band_um": wt_i,
        "GAN_I_band_um": gan_i,
    }).to_csv(out / "figure3_waveforms.csv", index=False)

    fig, ax = plt.subplots(figsize=(7.2, 4.3))
    ax.plot(t, wt_d, label="WT")
    ax.plot(t, gan_d, linestyle="--", label="GAN")
    ax.set(xlabel="Time (s)", ylabel="Z-disc diameter (um)", ylim=(0.65, 0.78))
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "figure3C_zdisc_diameter.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4.3))
    ax.plot(t, wt_i, label="WT")
    ax.plot(t, gan_i, linestyle="--", label="GAN")
    ax.set(xlabel="Time (s)", ylabel="I-band length (um)", ylim=(0.44, 0.71))
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "figure3D_iband_length.png", dpi=300)
    plt.close(fig)

    fig, ax1 = plt.subplots(figsize=(7.2, 4.3))
    ax1.plot(I, R)
    ax1.set_xlabel("I-band length (um)")
    ax1.set_ylabel("Radius (nm)")
    ax2 = ax1.twinx()
    ax2.plot(I, phi, linestyle="--")
    ax2.set_ylabel("Angle (degrees)")
    fig.tight_layout()
    fig.savefig(out / "geometry_mapping.png", dpi=300)
    plt.close(fig)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
