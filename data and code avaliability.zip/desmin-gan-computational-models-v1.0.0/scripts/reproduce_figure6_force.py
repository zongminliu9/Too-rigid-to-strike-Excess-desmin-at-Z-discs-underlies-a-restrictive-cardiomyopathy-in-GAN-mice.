#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from desmin_models.io import load_parameters, ensure_output_dir
from desmin_models.force import wlc_force_pN, aggregated_ring_tension_nN, hbond_threshold


def main() -> None:
    p = load_parameters()
    f = p["force"]
    out = ensure_output_dir("figure6_force")
    w = f["WLC"]
    single = wlc_force_pN(
        w["extension_nm"], w["contour_length_nm"], w["persistence_length_nm"], w["kBT_pN_nm"]
    )
    aggregate = aggregated_ring_tension_nN(
        single, w["titins_per_unit"], w["units"], w["projection_angle_deg"]
    )
    th = f["threshold"]
    threshold = hbond_threshold(
        th["passive_sarcomere_force_nN"], th["ring_diameter_nm"],
        th["transmission_spacing_nm"], th["hydrogen_bond_rupture_pN"],
    )
    summary = {
        "single_titin_WLC_force_pN": single,
        "aggregated_ring_tension_nN": aggregate,
        "threshold_model": threshold,
        "active_systolic_ring_force_nN": th["active_systolic_ring_force_nN"],
    }
    (out / "force_hbond_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    x = np.linspace(1, 0.85 * w["contour_length_nm"], 500)
    forces = np.array([
        wlc_force_pN(v, w["contour_length_nm"], w["persistence_length_nm"], w["kBT_pN_nm"])
        for v in x
    ])
    pd.DataFrame({"extension_nm": x, "WLC_force_pN": forces}).to_csv(
        out / "wlc_curve.csv", index=False
    )
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    ax.plot(x, forces)
    ax.axvline(w["extension_nm"], linestyle="--")
    ax.set(xlabel="Extension x (nm)", ylabel="Single-titin WLC force (pN)")
    fig.tight_layout()
    fig.savefig(out / "wlc_force_curve.png", dpi=300)
    plt.close(fig)

    t = np.linspace(0, 0.3, 1200)
    freq = 10.0
    force_nN = -12.5 * np.maximum(0, np.sin(2 * np.pi * freq * t)) + 4.0 * np.maximum(
        0, -np.sin(2 * np.pi * freq * t)
    )
    pd.DataFrame({"time_s": t, "force_nN": force_nN}).to_csv(
        out / "force_profile.csv", index=False
    )
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    ax.plot(t, force_nN)
    ax.axhline(3.0, linestyle="--", label="3-H-bond order")
    ax.axhline(4.0, linestyle=":", label="4-H-bond order")
    ax.set(xlabel="Time (s)", ylabel="Force (nN)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "figure6_force_profile.png", dpi=300)
    plt.close(fig)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
