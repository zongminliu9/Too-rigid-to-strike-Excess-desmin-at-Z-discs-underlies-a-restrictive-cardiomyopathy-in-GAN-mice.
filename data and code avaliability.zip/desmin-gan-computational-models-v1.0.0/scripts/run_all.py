#!/usr/bin/env python3
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

SCRIPTS = [
    "reproduce_figure3.py",
    "reproduce_figure5_calculations.py",
    "reproduce_figure6_force.py",
    "reproduce_figure7.py",
    "reproduce_figure7_sensitivity.py",
    "reproduce_figure8.py",
    "sequence_alignment.py",
    "prepare_af3_inputs.py",
]


def main() -> None:
    here = Path(__file__).resolve().parent
    for script in SCRIPTS:
        print(f"\n=== Running {script} ===")
        subprocess.run([sys.executable, str(here / script)], check=True)
    print("\nAll calculations completed.")


if __name__ == "__main__":
    main()
