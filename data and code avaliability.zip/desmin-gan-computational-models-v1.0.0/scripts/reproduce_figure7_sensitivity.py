#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
import numpy as np
import pandas as pd
from scipy.stats import qmc
import matplotlib.pyplot as plt
from desmin_models.io import load_parameters, ensure_output_dir
from desmin_models.dynamics import hysteresis_loop_area, relaxation_proxy


def main() -> None:
    p = load_parameters(); d = p["dynamics"]; q = d["reduced_equation"]; s = d["sensitivity"]
    out = ensure_output_dir("figure7_sensitivity")
    sampler = qmc.LatinHypercube(d=4, seed=s["seed"])
    sample = sampler.random(n=s["n_samples"])
    bounds_low = [s["rho_k_min"], s["damping_factor_min"], s["force_factor_min"], s["omega_factor_min"]]
    bounds_high = [s["rho_k_max"], s["damping_factor_max"], s["force_factor_max"], s["omega_factor_max"]]
    X = qmc.scale(sample, bounds_low, bounds_high)
    rows = []
    for rho, cfac, ffac, wfac in X:
        c = q["damping"] * cfac; F = q["force_amplitude"] * ffac; omega = q["omega_rad_s"] * wfac
        wt_area = hysteresis_loop_area(q["mass"], c, q["k_WT"], F, omega)
        gan_area = hysteresis_loop_area(q["mass"], c/rho, rho*q["k_WT"], F, omega)
        wt_tau = relaxation_proxy(q["mass"], c); gan_tau = relaxation_proxy(q["mass"], c/rho)
        rows.append({"rho_k": rho, "c": c, "F0": F, "omega": omega, "WT_loop_area": wt_area,
                     "GAN_loop_area": gan_area, "area_ratio_GAN_WT": gan_area/wt_area,
                     "WT_tau": wt_tau, "GAN_tau": gan_tau, "delta_tau": gan_tau-wt_tau})
    df = pd.DataFrame(rows); df.to_csv(out / "latin_hypercube_results.csv", index=False)
    summary = {"n_samples": len(df), "fraction_area_reduced": float((df.area_ratio_GAN_WT < 1).mean()),
               "fraction_relaxation_slower": float((df.delta_tau > 0).mean()),
               "area_ratio_min": float(df.area_ratio_GAN_WT.min()), "area_ratio_max": float(df.area_ratio_GAN_WT.max()),
               "delta_tau_min": float(df.delta_tau.min()), "delta_tau_max": float(df.delta_tau.max())}
    (out / "sensitivity_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    fig, ax = plt.subplots(figsize=(6.5, 4.2)); ax.scatter(df.rho_k, df.area_ratio_GAN_WT)
    ax.axhline(1, linestyle="--"); ax.set(xlabel="Stiffness ratio rho_k", ylabel="GAN/WT loop-area ratio")
    fig.tight_layout(); fig.savefig(out / "loop_area_robustness.png", dpi=300); plt.close(fig)
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
