#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from desmin_models.io import load_parameters, ensure_output_dir
from desmin_models.progression import fit_growth_rate, mu_per_arrival, expected_tangencies


def main() -> None:
    p = load_parameters()
    pr = p["progression"]
    out = ensure_output_dir("figure8_progression")
    k_fit = fit_growth_rate(pr["calibration_months"], pr["calibration_ratios"])
    k = pr["growth_rate_per_month"]

    model_rows = []
    curve_rows = []
    fig, ax = plt.subplots(figsize=(7.4, 4.8))
    for n0 in pr["initial_counts"]:
        mu = mu_per_arrival(pr["corridor_W_nm"], pr["disc_diameter_nm"], int(n0))
        end = float(pr["terminal_months"][n0])
        t = np.linspace(0, end, 400)
        tangencies = expected_tangencies(
            t, pr["corridor_W_nm"], pr["disc_diameter_nm"], int(n0), k
        )
        ax.plot(t, tangencies, label=f"N0={n0} (T={end:.2f} mo)")
        model_rows.append({"N0": n0, "terminal_month": end, **mu})
        curve_rows.extend(
            {"N0": n0, "month": float(ti), "expected_tangencies": float(yi)}
            for ti, yi in zip(t, tangencies)
        )
    ax.set(xlabel="Month", ylabel="Expected aberrant tangencies")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "figure8D_progression.png", dpi=300)
    plt.close(fig)
    pd.DataFrame(model_rows).to_csv(out / "progression_parameters.csv", index=False)
    pd.DataFrame(curve_rows).to_csv(out / "progression_curves.csv", index=False)

    fp = pr["force_profile"]
    t_force = np.linspace(0, fp["duration_s"], 1200)
    phase = np.sin(2 * np.pi * fp["frequency_hz"] * t_force)
    force = np.where(
        phase >= 0,
        fp["diastolic_amplitude_nN"] * phase,
        fp["systolic_amplitude_nN"] * phase,
    )
    pd.DataFrame({"time_s": t_force, "force_nN": force}).to_csv(
        out / "figure8C_force.csv", index=False
    )
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    ax.plot(t_force, force)
    ax.axhline(2, linestyle="--")
    ax.axhline(4, linestyle=":")
    ax.set(xlabel="Time (s)", ylabel="Force (nN)")
    fig.tight_layout()
    fig.savefig(out / "figure8C_force_threshold.png", dpi=300)
    plt.close(fig)

    pm = pr["population_model"]
    months = np.linspace(0, pm["duration_months"], 500)
    wt_internal = pm["WT_initial"] - pm["WT_decay_per_month"] * months
    gan_aberrant = pm["GAN_aberrant_max"] / (
        1 + np.exp(-(months - pm["GAN_aberrant_midpoint_month"]) / pm["GAN_aberrant_scale_month"])
    )
    gan_internal = 1.0 - pm["GAN_aberrant_max"] / (
        1 + np.exp(-(months - pm["GAN_internal_midpoint_month"]) / pm["GAN_internal_scale_month"])
    )
    pd.DataFrame({
        "month": months,
        "WT_2_hbond_population": wt_internal,
        "GAN_4_hbond_population": gan_aberrant,
        "GAN_2_hbond_population": gan_internal,
    }).to_csv(out / "figure8C_populations.csv", index=False)
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    ax.plot(months, wt_internal, label="WT 2-hbond")
    ax.plot(months, gan_aberrant, label="GAN 4-hbond")
    ax.plot(months, gan_internal, label="GAN 2-hbond")
    ax.set(xlabel="Month", ylabel="Assembly population")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "figure8C_population.png", dpi=300)
    plt.close(fig)

    summary = {
        "growth_rate_per_month": k,
        "fitted_growth_rate_per_month": k_fit,
        "model_parameters": model_rows,
    }
    (out / "progression_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
