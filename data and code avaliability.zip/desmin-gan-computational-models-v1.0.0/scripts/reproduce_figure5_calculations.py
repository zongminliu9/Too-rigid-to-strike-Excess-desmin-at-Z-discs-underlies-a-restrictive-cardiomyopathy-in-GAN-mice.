#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
import pandas as pd
import matplotlib.pyplot as plt
from desmin_models.io import load_parameters, ensure_output_dir
from desmin_models.packing import packing_requirement
from desmin_models.geometry import linker_contour_length, full_circumference_tiling


def main() -> None:
    p = load_parameters()
    out = ensure_output_dir("figure5_packing")
    pk, g = p["packing"], p["geometry"]
    rows = [
        packing_requirement(
            pk["W_nm"], pk["d_nm"], int(n0), pk["target_gap_count"], int(additional)
        )
        for n0, additional in pk["additional_filaments"].items()
    ]
    df = pd.DataFrame(rows)
    df.to_csv(out / "packing_ratio.csv", index=False)

    linker_max = linker_contour_length(
        g["per_layer"]["linker12_residues"], g["per_layer"]["contour_per_residue_nm"]
    )
    tiling = full_circumference_tiling(
        g["full_circumference"]["D_min_nm"], g["full_circumference"]["D_max_nm"],
        g["per_layer"]["rod_length_nm"], g["per_layer"]["rod_overlap_fraction"],
        g["full_circumference"]["N"], linker_max,
    )
    (out / "tiling_summary.json").write_text(json.dumps(tiling, indent=2), encoding="utf-8")

    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    ax.bar(df["n0"].astype(str), df["percent_increase"])
    ax.set(xlabel="Initial filament number n0", ylabel="Required increase (%)")
    fig.tight_layout()
    fig.savefig(out / "packing_ratio.png", dpi=300)
    plt.close(fig)
    print(df.to_string(index=False))
    print(json.dumps(tiling, indent=2))


if __name__ == "__main__":
    main()
