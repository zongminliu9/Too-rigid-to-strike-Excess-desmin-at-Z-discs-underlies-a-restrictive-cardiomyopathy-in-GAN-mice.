#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
from Bio import SeqIO
from desmin_models.io import load_parameters, project_root


def af3_job(name: str, sequences: list[tuple[str, str]], seeds: list[int]) -> dict:
    return {
        "name": name,
        "modelSeeds": seeds,
        "sequences": [{"protein": {"id": chain, "sequence": seq}} for chain, seq in sequences],
        "dialect": "alphafold3",
        "version": 1,
    }


def main() -> None:
    root = project_root()
    s = load_parameters()["structural"]
    rec = next(SeqIO.parse(root / "data/reference_sequences/P17661.fasta", "fasta"))
    seq = str(rec.seq)
    out = root / "data/structural_inputs"
    out.mkdir(parents=True, exist_ok=True)

    r1a, r1b = s["fragments"]["rod1"]
    r2a, r2b = s["fragments"]["rod2"]
    rod1 = seq[r1a - 1:r1b]
    rod2 = seq[r2a - 1:r2b]
    jobs = [
        af3_job("desmin_full_length", [("A", seq)], s["full_length_seeds"]),
        af3_job("mode1_rod2_rod2", [("A", rod2), ("B", rod2)], s["docking_seeds"]),
        af3_job("mode2_rod1_rod1", [("A", rod1), ("B", rod1)], s["docking_seeds"]),
        af3_job("mode3_rod1_rod2", [("A", rod1), ("B", rod2)], s["docking_seeds"]),
    ]
    for job in jobs:
        (out / f"{job['name']}.json").write_text(json.dumps(job, indent=2), encoding="utf-8")
    (out / "fragments.fasta").write_text(
        f">DES_rod1_{r1a}_{r1b}\n{rod1}\n>DES_rod2_{r2a}_{r2b}\n{rod2}\n",
        encoding="utf-8",
    )
    print(f"Wrote {len(jobs)} AlphaFold 3 input files to {out}")


if __name__ == "__main__":
    main()
