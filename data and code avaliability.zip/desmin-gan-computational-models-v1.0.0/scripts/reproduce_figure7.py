#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from desmin_models.io import load_parameters, ensure_output_dir
from desmin_models.dynamics import solve_linear_oscillator, manuscript_waveform, analytic_amplitude_phase


def main() -> None:
    p = load_parameters()
    d = p["dynamics"]
    out = ensure_output_dir("figure7_dynamics")

    q = d["reduced_equation"]
    t_eq = np.linspace(0, 8.0, 8001)
    wt_x, wt_v, wt_force = solve_linear_oscillator(
        t_eq, q["mass"], q["damping"], q["k_WT"], q["force_amplitude"], q["omega_rad_s"]
    )
    gan_k = q["k_WT"] * q["stiffness_ratio_GAN"]
    gan_c = q["damping"] / q["stiffness_ratio_GAN"]
    gan_x, gan_v, gan_force = solve_linear_oscillator(
        t_eq, q["mass"], gan_c, gan_k, q["force_amplitude"], q["omega_rad_s"]
    )
    pd.DataFrame({
        "time_reduced": t_eq,
        "WT_x": wt_x,
        "GAN_x": gan_x,
        "WT_velocity": wt_v,
        "GAN_velocity": gan_v,
        "WT_force": wt_force,
        "GAN_force": gan_force,
    }).to_csv(out / "reduced_oscillator.csv", index=False)

    wt_amp, wt_phase = analytic_amplitude_phase(
        q["mass"], q["damping"], q["k_WT"], q["force_amplitude"], q["omega_rad_s"]
    )
    gan_amp, gan_phase = analytic_amplitude_phase(
        q["mass"], gan_c, gan_k, q["force_amplitude"], q["omega_rad_s"]
    )

    r = d["figure7"]
    t = np.linspace(0, r["duration_s"], 1500)
    wt_I = manuscript_waveform(t, r["WT_mid_um"], r["WT_amplitude_um"], r["frequency_hz"], 0.0)
    gan_I = manuscript_waveform(t, r["GAN_mid_um"], r["GAN_amplitude_um"], r["frequency_hz"], 0.0)
    omega = 2 * np.pi * r["frequency_hz"]
    wt_F = r["force_amplitude_N"] * np.sin(omega * t + r["WT_phase_rad"])
    gan_F = r["force_amplitude_N"] * np.sin(omega * t + r["GAN_phase_rad"])
    pd.DataFrame({
        "time_s": t,
        "WT_I_band_um": wt_I,
        "GAN_I_band_um": gan_I,
        "WT_force_N": wt_F,
        "GAN_force_N": gan_F,
    }).to_csv(out / "figure7_dynamics.csv", index=False)

    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    ax.plot(t, wt_I, label="WT")
    ax.plot(t, gan_I, linestyle="--", label="GAN")
    ax.set(xlabel="Time (s)", ylabel="I-band length (um)", ylim=(0.44, 0.71))
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "figure7C_iband_dynamics.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    ax.plot(wt_I, wt_F, label="WT")
    ax.plot(gan_I, gan_F, linestyle="--", label="GAN")
    ax.set(xlabel="I-band length (um)", ylabel="Composite mechanical force (N)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "figure7D_hysteresis.png", dpi=300)
    plt.close(fig)

    fig = plt.figure(figsize=(8.0, 6.0))
    ax = fig.add_subplot(111, projection="3d")
    ax.plot(t, wt_I, wt_F, label="WT")
    ax.plot(t, gan_I, gan_F, label="GAN")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("I-band length (um)")
    ax.set_zlabel("Force (N)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out / "figure7B_3D_trajectory.png", dpi=300)
    plt.close(fig)

    summary = {
        "WT_amplitude": wt_amp,
        "WT_phase_rad": wt_phase,
        "GAN_amplitude": gan_amp,
        "GAN_phase_rad": gan_phase,
        "GAN_stiffness": gan_k,
        "GAN_damping": gan_c,
    }
    (out / "dynamics_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
