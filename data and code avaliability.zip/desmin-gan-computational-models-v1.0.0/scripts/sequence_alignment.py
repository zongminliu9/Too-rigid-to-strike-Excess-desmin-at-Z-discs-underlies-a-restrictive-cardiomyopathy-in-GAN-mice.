#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _bootstrap  # noqa: F401
from Bio import SeqIO
from Bio.Align import PairwiseAligner, substitution_matrices
from desmin_models.io import ensure_output_dir, project_root


def alignment_strings(alignment, seq_a: str, seq_b: str) -> tuple[str, str]:
    a_parts, b_parts = [], []
    c = alignment.coordinates
    for k in range(c.shape[1]-1):
        i0, i1, j0, j1 = c[0,k], c[0,k+1], c[1,k], c[1,k+1]
        di, dj = i1-i0, j1-j0
        if di and dj:
            a_parts.append(seq_a[i0:i1]); b_parts.append(seq_b[j0:j1])
        elif di:
            a_parts.append(seq_a[i0:i1]); b_parts.append("-"*di)
        else:
            a_parts.append("-"*dj); b_parts.append(seq_b[j0:j1])
    return "".join(a_parts), "".join(b_parts)


def main() -> None:
    root = project_root(); out = ensure_output_dir("sequence_alignment")
    a_rec = next(SeqIO.parse(root/"data/reference_sequences/P17661.fasta", "fasta"))
    b_rec = next(SeqIO.parse(root/"data/reference_sequences/P08670.fasta", "fasta"))
    a, b = str(a_rec.seq), str(b_rec.seq)
    matrix = substitution_matrices.load("BLOSUM62")
    aligner = PairwiseAligner(); aligner.mode = "global"; aligner.substitution_matrix = matrix
    aligner.open_gap_score = -10.0; aligner.extend_gap_score = -0.5
    aln = aligner.align(a, b)[0]
    aa, bb = alignment_strings(aln, a, b)
    pairs = [(x,y) for x,y in zip(aa,bb) if x != "-" and y != "-"]
    identity = 100*sum(x==y for x,y in pairs)/len(pairs)
    positive = 100*sum(matrix[x,y] > 0 for x,y in pairs)/len(pairs)
    matchline = "".join("|" if x==y else "+" if x!="-" and y!="-" and matrix[x,y]>0 else " " for x,y in zip(aa,bb))
    lines = []
    for i in range(0, len(aa), 80):
        lines.extend([f"DES {aa[i:i+80]}", f"    {matchline[i:i+80]}", f"VIM {bb[i:i+80]}", ""])
    (out/"desmin_vimentin_alignment.txt").write_text("\n".join(lines), encoding="utf-8")
    summary = {"desmin_length": len(a), "vimentin_length": len(b), "non_gap_pairs": len(pairs),
               "percent_identity": identity, "percent_BLOSUM62_positive": positive,
               "gap_open": -10.0, "gap_extend": -0.5, "mode": "global"}
    (out/"alignment_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
