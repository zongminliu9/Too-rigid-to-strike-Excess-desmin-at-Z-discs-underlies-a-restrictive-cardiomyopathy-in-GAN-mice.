from __future__ import annotations
import numpy as np


def fit_growth_rate(months: list[float], ratios: list[float]) -> float:
    t = np.asarray(months, dtype=float)
    y = np.log(np.asarray(ratios, dtype=float))
    return float(np.dot(t, y) / np.dot(t, t))


def mu_per_arrival(W_nm: float, d_nm: float, N0: int) -> dict:
    L = W_nm - d_nm
    delta = L / (N0 - 1)
    U = min(delta, 4.0 * d_nm)
    overlap = max(0.0, 2.0 * d_nm - delta)
    p1 = min(L, (N0 - 1) * U) / L
    p2 = (N0 - 1) * overlap / L
    return {"delta_nm": delta, "U_nm": U, "p1": p1, "p2": p2, "mu": p1 + p2}


def expected_tangencies(t_months: np.ndarray, W_nm: float, d_nm: float,
                         N0: int, growth_rate: float) -> np.ndarray:
    mu = mu_per_arrival(W_nm, d_nm, N0)["mu"]
    return mu * N0 * (np.exp(growth_rate * t_months) - 1.0)
