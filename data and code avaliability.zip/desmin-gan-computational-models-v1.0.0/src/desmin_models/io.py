from __future__ import annotations
from pathlib import Path
import yaml


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_parameters(path: str | Path | None = None) -> dict:
    p = Path(path) if path else project_root() / "config" / "parameters.yaml"
    with p.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def ensure_output_dir(name: str | None = None) -> Path:
    root = project_root() / "outputs"
    out = root / name if name else root
    out.mkdir(parents=True, exist_ok=True)
    return out
