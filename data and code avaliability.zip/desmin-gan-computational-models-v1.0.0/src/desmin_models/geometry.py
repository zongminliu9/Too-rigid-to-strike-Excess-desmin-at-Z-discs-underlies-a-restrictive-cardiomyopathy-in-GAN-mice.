from __future__ import annotations
import math
import numpy as np


def effective_rod_projection(rod_length_nm: float, overlap_fraction: float) -> float:
    return rod_length_nm * (1.0 - overlap_fraction / 2.0)


def linker_contour_length(n_residues: int = 16, nm_per_residue: float = 0.36) -> float:
    return n_residues * nm_per_residue


def circumference(diameter_nm: float) -> float:
    return math.pi * diameter_nm


def per_layer_ring_model(D_min_nm: float, D_max_nm: float, rod_length_nm: float,
                         overlap_fraction: float, linker_max_nm: float) -> dict:
    leff = effective_rod_projection(rod_length_nm, overlap_fraction)
    cmin, cmax = circumference(D_min_nm), circumference(D_max_nm)
    N_float = cmin / leff
    N = int(round(N_float))
    delta_linker = (cmax - cmin) / N
    relaxed_sum = N * leff
    contracted_sum = N * (leff + delta_linker)
    return {
        "L_eff_nm": leff,
        "C_min_nm": cmin,
        "C_max_nm": cmax,
        "N_float": N_float,
        "N_rounded": N,
        "delta_linker_nm": delta_linker,
        "linker_max_nm": linker_max_nm,
        "within_contour_limit": delta_linker <= linker_max_nm,
        "relaxed_sum_nm": relaxed_sum,
        "contracted_sum_nm": contracted_sum,
        "relaxed_error_pct": 100 * abs(relaxed_sum - cmin) / cmin,
        "contracted_error_pct": 100 * abs(contracted_sum - cmax) / cmax,
    }


def full_circumference_tiling(D_min_nm: float, D_max_nm: float, rod_length_nm: float,
                              overlap_fraction: float, N: int, linker_max_nm: float) -> dict:
    leff = effective_rod_projection(rod_length_nm, overlap_fraction)
    cmin, cmax = circumference(D_min_nm), circumference(D_max_nm)
    ext = (cmax - cmin) / N
    return {
        "N": N,
        "L_eff_nm": leff,
        "C_min_nm": cmin,
        "C_max_nm": cmax,
        "delta_C_nm": cmax - cmin,
        "delta_linker_nm": ext,
        "within_contour_limit": ext <= linker_max_nm,
        "rod_only_sum_nm": N * leff,
        "rod_only_deviation_pct": 100 * abs(N * leff - cmin) / cmin,
    }


def radius_from_iband(I_um: np.ndarray | float, I_min_um: float, I_max_um: float,
                      R_min_nm: float, R_max_nm: float) -> np.ndarray:
    I = np.asarray(I_um, dtype=float)
    return R_min_nm + (I_max_um - I) * (R_max_nm - R_min_nm) / (I_max_um - I_min_um)


def nebulin_angle_deg(I_um: np.ndarray | float, R_nm: np.ndarray | float,
                      titin_radius_nm: float) -> np.ndarray:
    I_nm = np.asarray(I_um, dtype=float) * 1000.0
    R = np.asarray(R_nm, dtype=float)
    return np.degrees(np.arctan2(R - titin_radius_nm, I_nm))


def sinusoid_between(t: np.ndarray, low: float, high: float, frequency_hz: float,
                     phase_rad: float = -math.pi / 2) -> np.ndarray:
    mid = 0.5 * (low + high)
    amp = 0.5 * (high - low)
    return mid + amp * np.sin(2 * math.pi * frequency_hz * t + phase_rad)
