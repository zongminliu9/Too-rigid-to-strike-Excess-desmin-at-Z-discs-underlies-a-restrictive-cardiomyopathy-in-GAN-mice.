from __future__ import annotations
import math


def wlc_force_pN(extension_nm: float, contour_length_nm: float,
                 persistence_length_nm: float, kBT_pN_nm: float) -> float:
    z = extension_nm / contour_length_nm
    if not 0 <= z < 1:
        raise ValueError("WLC extension ratio must satisfy 0 <= x/Lc < 1")
    return (kBT_pN_nm / persistence_length_nm) * (
        1.0 / (4.0 * (1.0 - z) ** 2) - 0.25 + z
    )


def aggregated_ring_tension_nN(single_titin_force_pN: float, titins_per_unit: int,
                                units: int, projection_angle_deg: float) -> float:
    projected_pN = single_titin_force_pN * titins_per_unit * math.cos(math.radians(projection_angle_deg))
    return projected_pN * units / 1000.0


def hbond_threshold(passive_force_nN: float, ring_diameter_nm: float,
                    transmission_spacing_nm: float, hbond_rupture_pN: float,
                    projection_angle_deg: float = 30.0) -> dict:
    ring_tension_nN = passive_force_nN * math.cos(math.radians(projection_angle_deg))
    circumference_nm = math.pi * ring_diameter_nm
    n_points = circumference_nm / transmission_spacing_nm
    force_per_point_pN = ring_tension_nN * 1000.0 / n_points
    bonds_per_point = force_per_point_pN / hbond_rupture_pN
    total_bonds = n_points * bonds_per_point
    return {
        "ring_tension_nN": ring_tension_nN,
        "circumference_nm": circumference_nm,
        "transmission_points": n_points,
        "force_per_point_pN": force_per_point_pN,
        "bonds_per_point": bonds_per_point,
        "total_bonds": total_bonds,
        "average_spacing_nm_per_bond": circumference_nm / total_bonds,
    }
