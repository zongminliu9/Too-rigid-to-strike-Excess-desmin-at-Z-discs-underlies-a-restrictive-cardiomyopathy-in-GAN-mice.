from __future__ import annotations


def packing_requirement(W_nm: float, d_nm: float, n0: int,
                        target_gaps: int, additional_filaments: int) -> dict:
    slack = W_nm - n0 * d_nm
    average_gap = slack / target_gaps
    fractional_increase = additional_filaments / n0
    return {
        "n0": n0,
        "slack_nm": slack,
        "average_target_gap_nm": average_gap,
        "additional_filaments": additional_filaments,
        "fractional_increase": fractional_increase,
        "percent_increase": 100.0 * fractional_increase,
    }
