"""Computational models for desmin-associated sarcomere mechanics."""
__version__ = "1.0.0"
