from __future__ import annotations
from pathlib import Path
import json
import numpy as np
from Bio.PDB import MMCIFParser, PDBParser


def read_structure(path: str | Path):
    p = Path(path)
    if p.suffix.lower() in {".cif", ".mmcif"}:
        return MMCIFParser(QUIET=True).get_structure(p.stem, str(p))
    return PDBParser(QUIET=True).get_structure(p.stem, str(p))


def interchain_contacts(path: str | Path, cutoff_A: float = 3.5) -> list[dict]:
    structure = read_structure(path)
    model = next(structure.get_models())
    chains = list(model.get_chains())
    contacts = []
    for i, chain_a in enumerate(chains):
        atoms_a = [a for a in chain_a.get_atoms() if a.element != "H"]
        for chain_b in chains[i + 1:]:
            atoms_b = [a for a in chain_b.get_atoms() if a.element != "H"]
            for aa in atoms_a:
                for bb in atoms_b:
                    dist = aa - bb
                    if dist <= cutoff_A:
                        ra, rb = aa.get_parent(), bb.get_parent()
                        contacts.append({
                            "chain_a": chain_a.id,
                            "residue_a": f"{ra.resname}{ra.id[1]}",
                            "atom_a": aa.name,
                            "chain_b": chain_b.id,
                            "residue_b": f"{rb.resname}{rb.id[1]}",
                            "atom_b": bb.name,
                            "distance_A": float(dist),
                        })
    return contacts


def load_pae(path: str | Path) -> np.ndarray:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(data, list) and data and "predicted_aligned_error" in data[0]:
        return np.asarray(data[0]["predicted_aligned_error"], dtype=float)
    if isinstance(data, dict):
        for key in ("predicted_aligned_error", "pae"):
            if key in data:
                return np.asarray(data[key], dtype=float)
    raise ValueError(f"Unrecognized PAE JSON structure: {path}")
