from __future__ import annotations
import math
import numpy as np
from scipy.integrate import solve_ivp


def solve_linear_oscillator(t: np.ndarray, mass: float, damping: float, stiffness: float,
                            force_amplitude: float, omega: float, x0: float = 0.0,
                            v0: float = 0.0) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    def rhs(time, y):
        x, v = y
        force = force_amplitude * math.sin(omega * time)
        a = (force - damping * v - stiffness * x) / mass
        return (v, a)
    sol = solve_ivp(rhs, (float(t[0]), float(t[-1])), (x0, v0), t_eval=t,
                    method="LSODA", rtol=1e-9, atol=1e-12)
    force = force_amplitude * np.sin(omega * t)
    return sol.y[0], sol.y[1], force


def analytic_amplitude_phase(mass: float, damping: float, stiffness: float,
                             force_amplitude: float, omega: float) -> tuple[float, float]:
    denom = math.sqrt((stiffness - mass * omega ** 2) ** 2 + (damping * omega) ** 2)
    amplitude = force_amplitude / denom
    phase = math.atan2(damping * omega, stiffness - mass * omega ** 2)
    return amplitude, phase


def hysteresis_loop_area(mass: float, damping: float, stiffness: float,
                         force_amplitude: float, omega: float) -> float:
    return (math.pi * force_amplitude ** 2 * damping * omega /
            ((stiffness - mass * omega ** 2) ** 2 + (damping * omega) ** 2))


def relaxation_proxy(mass: float, damping: float, fraction_remaining: float = 0.05) -> float:
    return 2.0 * mass / damping * math.log(1.0 / fraction_remaining)


def manuscript_waveform(t: np.ndarray, midpoint: float, amplitude: float,
                        frequency_hz: float, phase_rad: float = 0.0) -> np.ndarray:
    return midpoint + amplitude * np.sin(2 * np.pi * frequency_hz * t + phase_rad)
